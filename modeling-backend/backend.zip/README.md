\# Modeling Backend (Express + MongoDB)



این بخش بک‌اند پروژه‌ی مدلینگ هست. APIها برای مدیریت آگهی‌ها، کاربران و احراز هویت ساخته شده‌اند.



\## راه‌اندازی



```bash

\# نصب وابستگی‌ها

npm install



\# اجرای لوکال

npm run dev



