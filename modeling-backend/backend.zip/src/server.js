// src/server.js
// ---- Load .env BEFORE anything else ----
import 'dotenv/config';

import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import mongoose from 'mongoose';
import swaggerUi from 'swagger-ui-express';
import swaggerSpec from './docs/swagger.js';
import router from './routes/index.js';
import authDebugRouter from './routes/auth.debug.route.js';
import path from 'path';
import http from 'http';
import { Server as SocketIOServer } from 'socket.io';
import jwt from 'jsonwebtoken';

import {
  sendMessage,
  markThreadRead,
  unreadThreadCount,
} from './services/messaging.service.js';
import { notify } from './services/notification.service.js';

// --------- ENV CHECK ----------
const PORT = process.env.PORT || 4000;
const MONGO_URL = process.env.MONGO_URL || process.env.MONGO_URI;
const CORS_ORIGIN = process.env.CORS_ORIGIN || 'http://localhost:3000';
const JWT_SECRET = process.env.JWT_SECRET;

console.log('🔧 ENV CHECK:', {
  PORT,
  MONGO_URL_SET: !!MONGO_URL,
  JWT_SECRET_SET: !!JWT_SECRET,
  CORS_ORIGIN,
});

if (!JWT_SECRET) {
  console.error('❌ JWT_SECRET is NOT set. Add it to .env');
  process.exit(1);
}

// --------- Express ----------
const app = express();
app.use('/uploads', express.static(path.resolve(process.cwd(), 'uploads')));
app.use(helmet());
app.use(
  cors({
    origin: (CORS_ORIGIN || '*')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean),
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
  })
);
app.use(express.json());
app.use(morgan('dev'));

// Docs
app.use('/api/docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec, { explorer: true }));
app.get('/api/openapi.json', (req, res) => {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.send(JSON.stringify(swaggerSpec, null, 2));
});

// Routes
app.use('/api', router);
app.use('/api/v1/auth', authDebugRouter);
app.get('/api/ping', (_req, res) => res.json({ ok: true, msg: 'pong' }));
app.get('/', (_req, res) => res.send('Modeling backend is running ✅'));

// --------- HTTP + Socket.io ----------
const server = http.createServer(app);
const io = new SocketIOServer(server, {
  cors: { origin: CORS_ORIGIN, methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'] },
});

io.use((socket, next) => {
  try {
    const tokenFromAuth = socket.handshake?.auth?.token;
    const bearer = socket.handshake?.headers?.authorization;
    const token =
      tokenFromAuth ||
      (bearer && bearer.startsWith('Bearer ') ? bearer.slice(7) : null);
    if (!token) return next(new Error('No token'));
    const payload = jwt.verify(token, JWT_SECRET);
    socket.user = { _id: payload.sub, role: payload.role, email: payload.email };
    next();
  } catch {
    next(new Error('Unauthorized'));
  }
});

// (باقی رویدادهای socket هم مثل نسخه فعلی تو می‌مونه)

// --------- DB + Start ----------
mongoose
  .connect(MONGO_URL, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log('✅ MongoDB connected');
    server.listen(PORT, () => {
      console.log(`🚀 Server listening on http://localhost:${PORT}`);
      console.log('🔔 Socket.io ready');
    });
  })
  .catch((err) => {
    console.error('❌ MongoDB connection error:', err);
    process.exit(1);
  });
