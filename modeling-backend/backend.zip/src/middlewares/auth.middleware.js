// src/middlewares/auth.middleware.js
import jwt from 'jsonwebtoken';

/** اگر DEBUG_AUTH=1 باشد، پیام‌های دیباگ چاپ می‌شوند */
function dbg(tag, data) {
  if (process.env.DEBUG_AUTH === '1') {
    const stamp = new Date().toISOString();
    // از لو رفتن مقدار کامل توکن/سیکرت جلوگیری می‌کنیم
    const safe = (v) => {
      if (typeof v === 'string' && v.length > 64) return v.slice(0, 32) + '…' + v.slice(-6);
      return v;
    };
    try {
      console.log(`[AUTH][${stamp}] ${tag}`, typeof data === 'string' ? data : JSON.stringify(data, (k, v) => safe(v)));
    } catch {
      console.log(`[AUTH][${stamp}] ${tag}`, data);
    }
  }
}

function pickToken(req) {
  // 1) Authorization: Bearer <token>
  const a1 = req.headers?.authorization || req.headers?.Authorization;
  if (a1 && typeof a1 === 'string' && a1.startsWith('Bearer ')) {
    return a1.slice(7).trim();
  }
  // 2) x-access-token
  const a2 = req.headers?.['x-access-token'];
  if (a2 && typeof a2 === 'string') return a2.trim();
  // 3) ?token=...
  if (req.query?.token && typeof req.query.token === 'string') {
    return req.query.token.trim();
  }
  // 4) cookie: token=...
  const cookie = req.headers?.cookie || '';
  const m = cookie.match(/(?:^|;\s*)token=([^;]+)/i);
  if (m) return decodeURIComponent(m[1]);
  return null;
}

export function authRequired(req, res, next) {
  const token = pickToken(req);
  dbg('incoming', {
    method: req.method,
    url: req.originalUrl || req.url,
    hasAuthHeader: Boolean(req.headers?.authorization || req.headers?.Authorization),
    hasXAccessToken: Boolean(req.headers?.['x-access-token']),
    tokenLen: token ? token.length : 0,
    jwtSecretSet: Boolean(process.env.JWT_SECRET),
  });

  if (!token) {
    dbg('no-token', { message: 'توکن ارسال نشده' });
    return res.status(401).json({ ok: false, message: 'توکن لازم است' });
  }

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    dbg('decoded', {
      sub: payload?.sub,
      role: payload?.role,
      email: payload?.email,
      clientId: payload?.clientId || null,
      iat: payload?.iat,
      exp: payload?.exp,
      now: Math.floor(Date.now() / 1000),
    });

    // payload معمولاً: { sub, role, email, clientId?, iat, exp }
    req.token = token;
    req.user = {
      _id: payload.sub,
      sub: payload.sub,
      role: payload.role,
      email: payload.email,
      clientId: payload.clientId || null,
    };
    req.auth = payload;
    return next();
  } catch (err) {
    dbg('verify-failed', {
      name: err?.name,
      message: err?.message,
      code: err?.code,
    });
    return res.status(401).json({ ok: false, message: 'توکن نامعتبر است' });
  }
}

/** برای روت‌های عمومی که حضور توکن اختیاری است */
export function optionalAuth(req, _res, next) {
  const token = pickToken(req);
  if (!token) return next();
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.token = token;
    req.user = {
      _id: payload.sub,
      sub: payload.sub,
      role: payload.role,
      email: payload.email,
      clientId: payload.clientId || null,
    };
    req.auth = payload;
    dbg('optional-decoded', { url: req.originalUrl || req.url, role: req.user.role });
  } catch (err) {
    dbg('optional-verify-failed', { url: req.originalUrl || req.url, message: err?.message });
    //故 عمداً خطا نمی‌دهیم؛ مسیر عمومی باید ادامه پیدا کند
  }
  next();
}

export function requireRoles(...roles) {
  const allow = new Set(roles.map(String));
  return (req, res, next) => {
    const role = req.user?.role;
    if (!role || !allow.has(String(role))) {
      dbg('role-denied', { needed: [...allow], got: role });
      return res.status(403).json({ ok: false, message: 'دسترسی غیرمجاز' });
    }
    next();
  };
}
