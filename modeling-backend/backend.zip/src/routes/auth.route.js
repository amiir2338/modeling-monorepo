// src/routes/auth.route.js
import { Router } from 'express';
import { register, login, me } from '../controllers/auth.controller.js';
import { authLimiter } from '../middlewares/ratelimit.middleware.js';
import { authRequired } from '../middlewares/auth.middleware.js';

const router = Router();

// حساس‌ها با rate limit
router.post('/register', authLimiter, register);
router.post('/login', authLimiter, login);

// مسیر احراز هویت‌شده:
router.get('/me', authRequired, me);

export default router;
