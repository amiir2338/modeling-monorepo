// src/routes/auth.debug.route.js
import { Router } from 'express';
import { authRequired } from '../middlewares/auth.middleware.js';

const router = Router();

/**
 * GET /api/v1/auth/me
 * اگر توکن معتبر باشد، اطلاعات کاربر از JWT بازگردانده می‌شود.
 */
router.get('/me', authRequired, (req, res) => {
  res.json({ ok: true, user: req.user });
});

export default router;
