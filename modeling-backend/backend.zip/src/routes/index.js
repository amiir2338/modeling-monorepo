// src/routes/index.js
import { Router } from 'express';

// Feature routers
import healthRouter from './health.route.js';
import authRouter from './auth.route.js';
import authExtraRoute from './auth.extra.route.js';
import userMeRoute from './user.me.route.js';
import uploadRoute from './upload.route.js';

import modelsRoute from './models.route.js';
import clientsRoute from './clients.route.js';

import jobsRouter from './jobs.route.js';
import jobsModerationRoute from './jobs.moderation.route.js';
import applicationsRoute from './applications.route.js';
import notificationsRouter from './notifications.route.js';

// ✅ Messaging
import messagesRouter from './messages.route.js';
import threadsRouter from './threads.route.js';

// ✅ Debug for jobs
import jobsDebugRoute from './jobs.debug.route.js';

const router = Router();

/* ---------- Health ---------- */
router.use('/health', healthRouter);

/* ---------- Auth & User ---------- */
router.use('/v1/auth', authRouter);
router.use('/v1/auth', authExtraRoute);
router.use('/v1/users', userMeRoute);
router.use('/v1/upload', uploadRoute);

/* ---------- Model & Client ---------- */
router.use('/v1/models', modelsRoute);
router.use('/v1/clients', clientsRoute);

/* ---------- Jobs ---------- */
router.use('/v1/jobs', jobsRouter);
router.use('/v1/jobs', jobsModerationRoute);
router.use('/v1/jobs', jobsDebugRoute);  // ⬅️ اضافه شد

/* ---------- Applications ---------- */
router.use('/', applicationsRoute);

/* ---------- Notifications ---------- */
router.use('/', notificationsRouter);

/* ---------- Messaging ---------- */
router.use('/', messagesRouter);   // /api/v1/messages
router.use('/', threadsRouter);    // /api/v1/threads

export default router;
