// src/controllers/application.controller.js
import { z } from 'zod';
import mongoose from 'mongoose';
import Application from '../models/application.model.js';
import Job from '../models/job.model.js';

// -------- Helpers --------
const ObjectId = (v) => (typeof v === 'string' && mongoose.isValidObjectId(v));

const applySchema = z.object({
  note: z.string().max(2000).optional().nullish(),
  portfolioUrl: z.string().url().optional().nullish(),
  phone: z.string().min(3).max(32).optional().nullish(),
});

// وضعیت‌هایی که اجازهٔ Apply دارند را اینجا تعریف کن
const APPLY_ALLOWED_STATUSES = new Set(['approved', 'pending_review']);

// برای خروجی یکنواخت
function toJsonApplication(app) {
  if (!app) return null;
  return {
    _id: app._id,
    jobId: app.jobId,
    modelId: app.modelId,
    note: app.note ?? null,
    portfolioUrl: app.portfolioUrl ?? null,
    phone: app.phone ?? null,
    status: app.status ?? 'submitted',
    createdAt: app.createdAt,
    updatedAt: app.updatedAt,
  };
}

function forbid(res, message = 'Access denied') {
  return res.status(403).json({ ok: false, message });
}

function notFound(res, message = 'Not found') {
  return res.status(404).json({ ok: false, message });
}

// ========== Controllers ==========

/**
 * POST /api/v1/jobs/:id/apply
 * نقش: model
 * بدنهٔ ورودی: { note?, portfolioUrl?, phone? }
 * خروجی: { ok: true, application: {...} }
 */
export const applyToJob = async (req, res) => {
  try {
    if (!req.user || req.user.role !== 'model') {
      return forbid(res, 'Only models can apply to jobs');
    }

    const { id } = req.params;
    if (!ObjectId(id)) {
      return res.status(400).json({ ok: false, message: 'Invalid job id' });
    }

    // اعتبارسنجی ورودی
    const body = applySchema.parse(req.body || {});

    // آگهی را بیار
    const job = await Job.findById(id).lean();
    if (!job) return notFound(res, 'Job not found');

    // اجازه برای وضعیت‌های مشخص
    if (!APPLY_ALLOWED_STATUSES.has(job.status)) {
      return res
        .status(400)
        .json({ ok: false, message: 'Job not open for applications' });
    }

    // جلوگیری از ثبت تکراری
    const dup = await Application.findOne({
      jobId: job._id,
      modelId: req.user._id,
    }).lean();
    if (dup) {
      return res.status(409).json({ ok: false, message: 'Already applied' });
    }

    // ساخت اپلیکیشن
    const app = await Application.create({
      jobId: job._id,
      modelId: req.user._id,
      note: body.note ?? undefined,
      portfolioUrl: body.portfolioUrl ?? undefined,
      phone: body.phone ?? undefined,
      status: 'submitted',
    });

    return res.status(201).json({ ok: true, application: toJsonApplication(app) });
  } catch (err) {
    // Duplicate key (اگر ایندکسی گذاشتی)
    if (err?.code === 11000) {
      return res.status(409).json({ ok: false, message: 'Already applied' });
    }
    // Zod validation
    if (err?.issues?.length) {
      const msg = err.issues[0]?.message || 'Invalid input';
      return res.status(400).json({ ok: false, message: msg });
    }
    console.error('applyToJob error:', err?.message || err);
    return res.status(500).json({ ok: false, message: 'Server error' });
  }
};

/**
 * GET /api/v1/applications/mine
 * نقش: model
 * لیست اپلیکیشن‌هایی که مدل ارسال کرده
 */
export const getMyApplications = async (req, res) => {
  try {
    if (!req.user || req.user.role !== 'model') {
      return forbid(res, 'Only models can list their applications');
    }
    const apps = await Application.find({ modelId: req.user._id })
      .sort({ createdAt: -1 })
      .lean();

    return res.json({
      ok: true,
      items: apps.map(toJsonApplication),
    });
  } catch (err) {
    console.error('getMyApplications error:', err?.message || err);
    return res.status(500).json({ ok: false, message: 'Server error' });
  }
};

/**
 * GET /api/v1/jobs/:id/applications
 * نقش: admin یا مالکِ Job (client سازندهٔ آگهی)
 * لیست اپلیکیشن‌های یک آگهی
 */
export const getApplicationsForJob = async (req, res) => {
  try {
    const { id } = req.params;
    if (!ObjectId(id)) {
      return res.status(400).json({ ok: false, message: 'Invalid job id' });
    }

    const job = await Job.findById(id).lean();
    if (!job) return notFound(res, 'Job not found');

    // اجازه دسترسی: ادمین یا کلاینتِ صاحب آگهی
    const isAdmin = req.user?.role === 'admin';
    const isOwner =
      req.user?.role === 'client' &&
      job.clientId &&
      String(job.clientId) === String(req.user.clientId || req.user._id);

    if (!isAdmin && !isOwner) {
      return forbid(res, 'Not allowed to view applications for this job');
    }

    const apps = await Application.find({ jobId: job._id })
      .sort({ createdAt: -1 })
      .lean();

    return res.json({
      ok: true,
      items: apps.map(toJsonApplication),
    });
  } catch (err) {
    console.error('getApplicationsForJob error:', err?.message || err);
    return res.status(500).json({ ok: false, message: 'Server error' });
  }
};

/**
 * GET /api/v1/applications/:appId
 * نقش: admin، یا مدل صاحب اپلیکیشن، یا مالک آگهی (client)
 */
export const getApplicationById = async (req, res) => {
  try {
    const { appId } = req.params;
    if (!ObjectId(appId)) {
      return res.status(400).json({ ok: false, message: 'Invalid application id' });
    }

    const app = await Application.findById(appId).lean();
    if (!app) return notFound(res, 'Application not found');

    const job = await Job.findById(app.jobId).lean().catch(() => null);

    // دسترسی:
    const isAdmin = req.user?.role === 'admin';
    const isApplicant = req.user && String(app.modelId) === String(req.user._id);
    const isJobOwner =
      req.user?.role === 'client' &&
      job?.clientId &&
      String(job.clientId) === String(req.user.clientId || req.user._id);

    if (!isAdmin && !isApplicant && !isJobOwner) {
      return forbid(res, 'Not allowed to view this application');
    }

    return res.json({ ok: true, application: toJsonApplication(app) });
  } catch (err) {
    console.error('getApplicationById error:', err?.message || err);
    return res.status(500).json({ ok: false, message: 'Server error' });
  }
};

/**
 * PATCH /api/v1/applications/:appId/status
 * نقش: admin یا مالکِ Job
 * بدنه: { status: 'accepted' | 'rejected' | 'reviewing' | ... }
 */
export const updateApplicationStatus = async (req, res) => {
  try {
    const { appId } = req.params;
    if (!ObjectId(appId)) {
      return res.status(400).json({ ok: false, message: 'Invalid application id' });
    }

    const statusSchema = z.object({
      status: z.enum(['accepted', 'rejected', 'reviewing', 'submitted']),
    });
    const data = statusSchema.parse(req.body || {});

    const app = await Application.findById(appId);
    if (!app) return notFound(res, 'Application not found');

    const job = await Job.findById(app.jobId).lean();
    const isAdmin = req.user?.role === 'admin';
    const isJobOwner =
      req.user?.role === 'client' &&
      job?.clientId &&
      String(job.clientId) === String(req.user.clientId || req.user._id);

    if (!isAdmin && !isJobOwner) {
      return forbid(res, 'Not allowed to update this application');
    }

    app.status = data.status;
    await app.save();

    return res.json({ ok: true, application: toJsonApplication(app) });
  } catch (err) {
    if (err?.issues?.length) {
      const msg = err.issues[0]?.message || 'Invalid input';
      return res.status(400).json({ ok: false, message: msg });
    }
    console.error('updateApplicationStatus error:', err?.message || err);
    return res.status(500).json({ ok: false, message: 'Server error' });
  }
};
